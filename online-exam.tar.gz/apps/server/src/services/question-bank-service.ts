import { nanoid } from "nanoid";
import { ImportPreviewQuestion } from "@online-exam/shared";
import { db } from "../db/database.js";
import { nowIso } from "../utils/time.js";

export function createQuestionBankFromImport(params: {
  bankName: string;
  bankVersion: string;
  questions: ImportPreviewQuestion[];
  importedBy: string;
}) {
  const { bankName, bankVersion, questions, importedBy } = params;
  const now = nowIso();
  const bankId = nanoid();

  const singleCount = questions.filter((item) => item.questionType === "single").length;
  const judgeCount = questions.filter((item) => item.questionType === "judge").length;
  const categoryCount = new Set(questions.map((item) => item.category)).size;

  const insertBank = db.prepare(`
    INSERT INTO question_banks (
      id, name, version, status, total_count, single_count, judge_count, category_count,
      imported_by, imported_at, published_by, published_at, created_at, updated_at
    ) VALUES (
      @id, @name, @version, @status, @total_count, @single_count, @judge_count, @category_count,
      @imported_by, @imported_at, @published_by, @published_at, @created_at, @updated_at
    )
  `);

  const insertQuestion = db.prepare(`
    INSERT INTO questions (
      id, bank_id, category, question_type, source_no, stem, option_a, option_b, option_c, option_d,
      correct_answer, sort_no, is_active, created_at, updated_at
    ) VALUES (
      @id, @bank_id, @category, @question_type, @source_no, @stem, @option_a, @option_b, @option_c, @option_d,
      @correct_answer, @sort_no, @is_active, @created_at, @updated_at
    )
  `);

  const transaction = db.transaction(() => {
    insertBank.run({
      id: bankId,
      name: bankName,
      version: bankVersion,
      status: "imported",
      total_count: questions.length,
      single_count: singleCount,
      judge_count: judgeCount,
      category_count: categoryCount,
      imported_by: importedBy,
      imported_at: now,
      published_by: null,
      published_at: null,
      created_at: now,
      updated_at: now,
    });

    questions.forEach((question, index) => {
      insertQuestion.run({
        id: nanoid(),
        bank_id: bankId,
        category: question.category,
        question_type: question.questionType,
        source_no: question.sourceNo,
        stem: question.stem,
        option_a: question.optionA,
        option_b: question.optionB,
        option_c: question.optionC,
        option_d: question.optionD,
        correct_answer: question.correctAnswer,
        sort_no: index + 1,
        is_active: 1,
        created_at: now,
        updated_at: now,
      });
    });
  });

  transaction();
  return bankId;
}
