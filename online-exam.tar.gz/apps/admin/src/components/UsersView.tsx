import { Button, Card, Col, Form, Input, Row, Table, Tag } from "antd";
import { UserAddOutlined } from "@ant-design/icons";
import { formatDate, request } from "../lib/api";
import { formatUserStatus } from "../lib/labels";
import type { AdminUser } from "../types";

type NotifyKind = "success" | "warning" | "error";

function statusTag(status: string) {
  return <Tag color={status === "enabled" ? "success" : "default"}>{formatUserStatus(status)}</Tag>;
}

export default function UsersView({
  token,
  users,
  onReload,
  onNotify,
}: {
  token: string;
  users: AdminUser[];
  onReload: () => Promise<void>;
  onNotify: (kind: NotifyKind, text: string) => void;
}) {
  const [form] = Form.useForm<{ username: string; realName: string; phone: string; password: string }>();

  async function createUser(values: { username: string; realName: string; phone: string; password: string }) {
    try {
      await request("/api/admin/users", { method: "POST", body: JSON.stringify(values) }, token);
      form.resetFields();
      onNotify("success", "用户已创建");
      await onReload();
    } catch (error) {
      onNotify("error", (error as Error).message);
    }
  }

  async function updateUserStatus(userId: string, status: "enabled" | "disabled") {
    try {
      await request(`/api/admin/users/${userId}/status`, { method: "POST", body: JSON.stringify({ status }) }, token);
      onNotify("success", status === "enabled" ? "用户已启用" : "用户已停用");
      await onReload();
    } catch (error) {
      onNotify("error", (error as Error).message);
    }
  }

  return (
    <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
      <Col xs={24} xl={9}>
        <Card title="新增练习用户" extra={<UserAddOutlined />}>
          <Form form={form} layout="vertical" initialValues={{ password: "123456" }} onFinish={(values) => void createUser(values)}>
            <Form.Item label="用户名" name="username" rules={[{ required: true }]}><Input /></Form.Item>
            <Form.Item label="姓名" name="realName" rules={[{ required: true }]}><Input /></Form.Item>
            <Form.Item label="手机号" name="phone" rules={[{ required: true }]}><Input /></Form.Item>
            <Form.Item label="初始密码" name="password" rules={[{ required: true }]}><Input.Password /></Form.Item>
            <Button type="primary" htmlType="submit">创建用户</Button>
          </Form>
        </Card>
      </Col>
      <Col xs={24} xl={15}>
        <Card title="用户列表">
          <Table
            rowKey="id"
            dataSource={users}
            pagination={{ pageSize: 6 }}
            columns={[
              { title: "用户名", dataIndex: "username" },
              { title: "姓名", dataIndex: "realName" },
              { title: "手机号", dataIndex: "phone" },
              { title: "状态", dataIndex: "status", render: (value: string) => statusTag(value) },
              { title: "最近登录", dataIndex: "lastLoginAt", render: (value: string | null) => formatDate(value) },
              {
                title: "操作",
                render: (_, record: AdminUser) => (
                  <Button size="small" onClick={() => void updateUserStatus(record.id, record.status === "enabled" ? "disabled" : "enabled")}>
                    {record.status === "enabled" ? "停用" : "启用"}
                  </Button>
                ),
              },
            ]}
          />
        </Card>
      </Col>
    </Row>
  );
}
