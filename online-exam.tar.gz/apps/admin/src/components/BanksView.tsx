import { useState } from "react";
import {
  Alert,
  Button,
  Card,
  Col,
  Descriptions,
  Input,
  Row,
  Space,
  Spin,
  Statistic,
  Table,
  Tag,
  Typography,
  Upload,
} from "antd";
import { CloudUploadOutlined, FileExcelOutlined } from "@ant-design/icons";
import { API_BASE, request } from "../lib/api";
import type { BankDetail, ImportJob, QuestionBank } from "../types";

const { Text } = Typography;

function statusTag(status: string) {
  const colorMap: Record<string, string> = {
    published: "success",
    imported: "processing",
    disabled: "default",
  };
  const labelMap: Record<string, string> = {
    published: "已发布",
    imported: "待发布",
    disabled: "已停用",
    draft: "草稿",
  };
  return <Tag color={colorMap[status] ?? "default"}>{labelMap[status] ?? status}</Tag>;
}

function questionTypeLabel(value: string) {
  if (value === "single") return "单选题";
  if (value === "judge") return "判断题";
  return value;
}

function answerLabel(question: BankDetail["questions"][number]) {
  const optionMap: Record<string, string | null | undefined> = {
    A: question.option_a,
    B: question.option_b,
    C: question.option_c,
    D: question.option_d,
  };
  const optionText = optionMap[question.correct_answer];
  return optionText ? `${question.correct_answer}：${optionText}` : question.correct_answer;
}

function renderOptions(question: BankDetail["questions"][number]) {
  const options = [
    { key: "A", text: question.option_a },
    { key: "B", text: question.option_b },
    { key: "C", text: question.option_c },
    { key: "D", text: question.option_d },
  ].filter((item) => item.text);

  return (
    <Space direction="vertical" size={2}>
      {options.map((item) => (
        <Text key={item.key}>{`${item.key}. ${item.text}`}</Text>
      ))}
    </Space>
  );
}

type NotifyKind = "success" | "warning" | "error";

type Props = {
  token: string;
  banks: QuestionBank[];
  importJob: ImportJob | null;
  setImportJob: (job: ImportJob | null) => void;
  setSelectedBankId: (id: string) => void;
  bankDetail: BankDetail | null;
  detailLoading: boolean;
  onReload: () => Promise<void>;
  onNotify: (kind: NotifyKind, text: string) => void;
};

export default function BanksView({
  token,
  banks,
  importJob,
  setImportJob,
  setSelectedBankId,
  bankDetail,
  detailLoading,
  onReload,
  onNotify,
}: Props) {
  const [uploading, setUploading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [publishingBankId, setPublishingBankId] = useState("");
  const [disablingBankId, setDisablingBankId] = useState("");

  async function downloadTemplate() {
    try {
      const response = await fetch(`${API_BASE}/api/admin/question-banks/template`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: "模板下载失败" }));
        throw new Error(error.message ?? "模板下载失败");
      }
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "question-bank-template.xlsx";
      link.click();
      window.URL.revokeObjectURL(url);
      onNotify("success", "模板已下载");
    } catch (error) {
      onNotify("error", (error as Error).message);
    }
  }

  async function handleImportFile(file: File) {
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const response = await fetch(`${API_BASE}/api/admin/import-jobs/upload`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });
      const result = await response.json();
      if (!response.ok) {
        onNotify("error", result.message ?? "上传失败");
        return false;
      }
      setImportJob(result);
      onNotify(
        result.canImport ? "success" : "warning",
        result.canImport ? "题库校验通过，可继续导入" : "题库存在校验问题，请先修正",
      );
    } catch (error) {
      onNotify("error", (error as Error).message || "上传失败");
    } finally {
      setUploading(false);
    }
    return false;
  }

  async function confirmImport() {
    if (!importJob) return;
    const bankName = importJob.bankName.trim();
    if (!bankName) {
      onNotify("warning", "请先填写题库名称");
      return;
    }
    setImporting(true);
    try {
      const result = await request<{ bankId: string }>(
        `/api/admin/import-jobs/${importJob.jobId}/import`,
        {
          method: "POST",
          body: JSON.stringify({ bankName }),
        },
        token,
      );
      await onReload();
      setSelectedBankId(result.bankId);
      setImportJob(null);
      onNotify("success", `导入成功：${bankName} ${importJob.bankVersion || ""}`.trim());
    } catch (error) {
      onNotify("error", `导入失败：${(error as Error).message}`);
    } finally {
      setImporting(false);
    }
  }

  async function updateBankStatus(bankId: string, action: "publish" | "disable") {
    if (action === "publish") setPublishingBankId(bankId);
    if (action === "disable") setDisablingBankId(bankId);
    try {
      await request(`/api/admin/question-banks/${bankId}/${action}`, { method: "POST" }, token);
      await onReload();
      setSelectedBankId(bankId);
      onNotify("success", action === "publish" ? "题库已发布" : "题库已停用");
    } catch (error) {
      onNotify("error", `${action === "publish" ? "发布失败" : "停用失败"}：${(error as Error).message}`);
    } finally {
      if (action === "publish") setPublishingBankId("");
      if (action === "disable") setDisablingBankId("");
    }
  }

  return (
    <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
      <Col xs={24} xl={10}>
        <Card
          title="题库导入"
          extra={<Button icon={<FileExcelOutlined />} onClick={() => void downloadTemplate()}>下载模板</Button>}
        >
          <Space direction="vertical" style={{ width: "100%" }} size="middle">
            <Upload beforeUpload={(file) => handleImportFile(file)} maxCount={1} accept=".xlsx" showUploadList={false}>
              <Button type="primary" icon={<CloudUploadOutlined />} loading={uploading} block>
                上传 Excel 并校验
              </Button>
            </Upload>
            {importJob ? (
              <>
                <Descriptions size="small" bordered column={1}>
                  <Descriptions.Item label="题库版本">{importJob.bankVersion || "未识别"}</Descriptions.Item>
                  <Descriptions.Item label="统计">
                    总行数 {importJob.totalRows} / 通过 {importJob.successRows} / 失败 {importJob.failedRows}
                  </Descriptions.Item>
                </Descriptions>
                {importJob.canImport ? (
                  <Space direction="vertical" style={{ width: "100%" }}>
                    <div>
                      <Text style={{ display: "block", marginBottom: 8 }}>题库名称</Text>
                      <Input
                        placeholder="请输入本次导入的题库名称"
                        value={importJob.bankName}
                        onChange={(event) => setImportJob({ ...importJob, bankName: event.target.value })}
                      />
                    </div>
                    <Button type="primary" loading={importing} onClick={() => void confirmImport()}>
                      确认导入
                    </Button>
                  </Space>
                ) : (
                  <Alert
                    type="warning"
                    showIcon
                    message="校验失败"
                    description={
                      <Space direction="vertical">
                        {importJob.errors.slice(0, 8).map((item) => (
                          <Text key={`${item.row}-${item.column}`}>{`第 ${item.row} 行 / ${item.column}：${item.message}`}</Text>
                        ))}
                      </Space>
                    }
                  />
                )}
              </>
            ) : (
              <Alert type="info" showIcon message="支持标准 Excel 模板导入，上传后会先校验，再允许导入。" />
            )}
          </Space>
        </Card>
      </Col>
      <Col xs={24} xl={14}>
        <Card title="题库版本">
          <Table
            rowKey="id"
            pagination={{ pageSize: 5 }}
            dataSource={banks}
            columns={[
              {
                title: "题库",
                render: (_, record: QuestionBank) => (
                  <Button type="link" onClick={() => setSelectedBankId(record.id)}>
                    {record.name} / {record.version}
                  </Button>
                ),
              },
              { title: "状态", dataIndex: "status", render: (value: string) => statusTag(value) },
              { title: "总题数", dataIndex: "totalCount" },
              {
                title: "操作",
                render: (_, record: QuestionBank) => (
                  <Space>
                    <Button
                      size="small"
                      type={record.status === "published" ? "default" : "primary"}
                      disabled={record.status === "published" || disablingBankId === record.id}
                      loading={publishingBankId === record.id}
                      onClick={() => void updateBankStatus(record.id, "publish")}
                    >
                      {record.status === "published" ? "已发布" : "发布"}
                    </Button>
                    <Button
                      size="small"
                      danger
                      disabled={record.status === "disabled" || publishingBankId === record.id}
                      loading={disablingBankId === record.id}
                      onClick={() => void updateBankStatus(record.id, "disable")}
                    >
                      {record.status === "disabled" ? "已停用" : "停用"}
                    </Button>
                  </Space>
                ),
              },
            ]}
          />
        </Card>
      </Col>
      <Col span={24}>
        <Card title={bankDetail ? `${bankDetail.name} / ${bankDetail.version}` : "题库详情"}>
          <Spin spinning={detailLoading}>
            {bankDetail ? (
              <Space direction="vertical" style={{ width: "100%" }} size="large">
                <Descriptions bordered size="small" column={{ xs: 1, md: 3 }}>
                  <Descriptions.Item label="状态">{statusTag(bankDetail.status)}</Descriptions.Item>
                  <Descriptions.Item label="总题数">{bankDetail.totalCount}</Descriptions.Item>
                  <Descriptions.Item label="分类数">{bankDetail.categories.length}</Descriptions.Item>
                </Descriptions>
                <Row gutter={[12, 12]}>
                  {bankDetail.categories.map((item) => (
                    <Col xs={12} md={8} xl={6} key={item.category}>
                      <Card size="small">
                        <Statistic title={item.category} value={item.count} />
                      </Card>
                    </Col>
                  ))}
                </Row>
                <Table
                  rowKey="id"
                  pagination={{ pageSize: 6 }}
                  dataSource={bankDetail.questions}
                  columns={[
                    { title: "分类", dataIndex: "category", width: 120 },
                    { title: "题型", dataIndex: "question_type", width: 100, render: (value: string) => questionTypeLabel(value) },
                    { title: "题号", dataIndex: "source_no", width: 100, render: (value: string) => value || "-" },
                    { title: "题干", dataIndex: "stem", width: 280 },
                    { title: "选项", render: (_, record: BankDetail["questions"][number]) => renderOptions(record), width: 260 },
                    { title: "答案", render: (_, record: BankDetail["questions"][number]) => answerLabel(record), width: 200 },
                  ]}
                />
              </Space>
            ) : (
              <Alert type="info" showIcon message="点击上方题库记录查看详细信息" />
            )}
          </Spin>
        </Card>
      </Col>
    </Row>
  );
}
