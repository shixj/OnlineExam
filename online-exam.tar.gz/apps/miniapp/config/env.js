const DEFAULT_API_BASE = "http://127.0.0.1:3000";

module.exports = {
  API_BASE: DEFAULT_API_BASE,
  REQUEST_TIMEOUT: 15000,
};
