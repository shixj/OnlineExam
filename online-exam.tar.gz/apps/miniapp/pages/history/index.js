const api = require("../../utils/api");
const { requireLogin } = require("../../utils/auth");
const { formatDate, formatSessionMode, formatSessionStatus } = require("../../utils/labels");

Page({
  data: {
    loading: true,
    error: "",
    history: [],
  },
  onShow() {
    void this.loadHistory();
  },
  async loadHistory() {
    if (!requireLogin()) return;

    this.setData({
      loading: true,
      error: "",
    });

    try {
      const items = await api.getPracticeHistory();
      const history = items.map((item) => ({
        ...item,
        modeLabel: formatSessionMode(item.mode),
        statusLabel: formatSessionStatus(item.status),
        startedAtText: formatDate(item.started_at),
        submittedAtText: formatDate(item.submitted_at),
        statusClass: item.status === "completed" ? "status-tag status-tag--success" : "status-tag status-tag--active",
      }));

      this.setData({ history });
    } catch (error) {
      this.setData({
        error: error.message || "历史记录加载失败",
      });
    } finally {
      this.setData({
        loading: false,
      });
    }
  },
});
